#!/bin/bash
set -e

[[ $EUID -eq 0 ]] && SUDO="" || SUDO="sudo"

$SUDO systemctl stop codazzy-agent 2>/dev/null || true
$SUDO systemctl disable codazzy-agent 2>/dev/null || true
$SUDO rm -f /etc/systemd/system/codazzy-agent.service
$SUDO systemctl daemon-reload

read -p "Eliminar /opt/codazzy-agent? [y/N]: " r
[[ "$r" =~ ^[Yy]$ ]] && rm -rf /opt/codazzy-agent

echo "Desinstalado"
