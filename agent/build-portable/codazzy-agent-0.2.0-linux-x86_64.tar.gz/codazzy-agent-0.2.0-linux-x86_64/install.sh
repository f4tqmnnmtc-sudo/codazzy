#!/bin/bash
set -e

DIR="/opt/codazzy-agent"
CFG="$DIR/config"

[ ! -f "./codazzy-agent" ] && { echo "Ejecuta desde el directorio del paquete"; exit 1; }

[[ $EUID -eq 0 ]] && SUDO="" || SUDO="sudo"

systemctl is-active --quiet codazzy-agent 2>/dev/null && $SUDO systemctl stop codazzy-agent

mkdir -p "$DIR" "$CFG"
cp "./codazzy-agent" "$DIR/"
chmod +x "$DIR/codazzy-agent"

NATS_HOST="${NATS_HOST:-nats}"
sed "s/\${NATS_HOST:-nats}/$NATS_HOST/g" "./config.toml" > "$CFG/config.toml"
$SUDO mkdir -p /etc/codazzy/agent
$SUDO cp "$CFG/config.toml" /etc/codazzy/agent/

$SUDO tee /etc/systemd/system/codazzy-agent.service >/dev/null << EOSVC
[Unit]
Description=Codazzy Agent
After=network.target

[Service]
Type=simple
ExecStart=$DIR/codazzy-agent --config /etc/codazzy/agent/config.toml
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOSVC

$SUDO systemctl daemon-reload
$SUDO systemctl enable codazzy-agent
$SUDO systemctl start codazzy-agent

echo "Instalado en $DIR"
echo "Config: $CFG/config.toml"
echo "Logs: journalctl -u codazzy-agent -f"
